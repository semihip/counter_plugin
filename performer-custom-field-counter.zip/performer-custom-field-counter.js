(function () {
    "use strict";

    // ============================================================
    // STASH VERSION
    // Target: Stash v0.31.1
    // ============================================================

    var PluginApi = window.PluginApi;

    if (!PluginApi) {
        console.error("[Performer Custom Field Counter] PluginApi is not available.");
        return;
    }

    var React = PluginApi.React;

    if (!React) {
        console.error("[Performer Custom Field Counter] PluginApi.React is not available.");
        return;
    }

    // ============================================================
    // CONFIGURATION
    // ============================================================

    var CONFIG = {
        fieldName: "swallowed",
        volumeFactor: 0.00343642611,
        cacheDuration: 5 * 60 * 1000,
        hideZero: false,
        debug: true
    };

    // ============================================================
    // CACHE
    // ============================================================

    var cache = new Map();
    var pendingRequests = new Map();

    // ============================================================
    // GRAPHQL
    // ============================================================

    async function graphql(query, variables) {
        var response = await fetch("/graphql", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                query: query,
                variables: variables || {}
            })
        });

        var json;

        try {
            json = await response.json();
        } catch (error) {
            throw new Error(
                "Unable to parse GraphQL response. HTTP " + response.status
            );
        }

        if (!response.ok) {
            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                JSON.stringify(json)
            );
        }

        if (json.errors) {
            throw new Error(
                "GraphQL errors: " + JSON.stringify(json.errors)
            );
        }

        return json.data;
    }

    // ============================================================
    // LOAD PERFORMER TOTAL
    // ============================================================

    async function getPerformerTotal(performerId) {
        var id = String(performerId);
        var cached = cache.get(id);

        if (cached) {
            if (Date.now() - cached.loadedAt < CONFIG.cacheDuration) {
                if (CONFIG.debug) {
                    console.log(
                        "[Performer Custom Field Counter] CACHE:",
                        id,
                        cached.value
                    );
                }

                return cached.value;
            }

            cache.delete(id);
        }

        if (pendingRequests.has(id)) {
            return pendingRequests.get(id);
        }

        var request = (async function () {
            if (CONFIG.debug) {
                console.log(
                    "[Performer Custom Field Counter] Loading performer:",
                    id
                );
            }

            var query =
                "query PerformerCustomFieldCounter($id: ID!) {" +
                " findPerformer(id: $id) {" +
                "   id name scene_count" +
                "   scenes { id custom_fields }" +
                " }" +
                "}";

            var data;

            try {
                data = await graphql(query, { id: id });
            } catch (error) {
                console.error(
                    "[Performer Custom Field Counter] GraphQL error for performer " +
                    id +
                    ":",
                    error
                );

                return 0;
            }

            if (!data || !data.findPerformer) {
                console.warn(
                    "[Performer Custom Field Counter] Performer not found:",
                    id
                );

                return 0;
            }

            var performer = data.findPerformer;
            var scenes = performer.scenes || [];
            var total = 0;

            for (var i = 0; i < scenes.length; i++) {
                var scene = scenes[i];

                if (!scene || !scene.custom_fields) {
                    continue;
                }

                var rawValue = scene.custom_fields[CONFIG.fieldName];

                if (
                    rawValue === null ||
                    rawValue === undefined ||
                    rawValue === ""
                ) {
                    continue;
                }

                var numericValue = Number(rawValue);

                if (
                    !isFinite(numericValue) ||
                    Math.floor(numericValue) !== numericValue
                ) {
                    if (CONFIG.debug) {
                        console.warn(
                            "[Performer Custom Field Counter] Ignoring non-integer value:",
                            rawValue,
                            "Scene:",
                            scene.id
                        );
                    }

                    continue;
                }

                total += numericValue;
            }

            cache.set(id, {
                value: total,
                loadedAt: Date.now()
            });

            if (CONFIG.debug) {
                console.log(
                    "[Performer Custom Field Counter] TOTAL:",
                    performer.name,
                    "=",
                    total
                );
            }

            return total;
        })();

        pendingRequests.set(id, request);

        try {
            return await request;
        } finally {
            pendingRequests.delete(id);
        }
    }

    // ============================================================
    // LOAD SCENE VALUE
    // ============================================================

    async function getSceneValue(sceneId) {
        var id = String(sceneId);
        var cacheKey = "scene:" + id;
        var cached = cache.get(cacheKey);

        if (cached) {
            if (Date.now() - cached.loadedAt < CONFIG.cacheDuration) {
                if (CONFIG.debug) {
                    console.log(
                        "[Performer Custom Field Counter] SCENE CACHE:",
                        id,
                        cached.value
                    );
                }

                return cached.value;
            }

            cache.delete(cacheKey);
        }

        if (pendingRequests.has(cacheKey)) {
            return pendingRequests.get(cacheKey);
        }

        var request = (async function () {
            if (CONFIG.debug) {
                console.log(
                    "[Performer Custom Field Counter] Loading scene:",
                    id
                );
            }

            var query =
                "query SceneCustomFieldCounter($id: ID!) {" +
                " findScene(id: $id) { id title custom_fields }" +
                "}";

            var data;

            try {
                data = await graphql(query, { id: id });
            } catch (error) {
                console.error(
                    "[Performer Custom Field Counter] GraphQL error for scene " +
                    id +
                    ":",
                    error
                );

                return 0;
            }

            if (!data || !data.findScene) {
                console.warn(
                    "[Performer Custom Field Counter] Scene not found:",
                    id
                );

                return 0;
            }

            var scene = data.findScene;
            var rawValue = scene.custom_fields
                ? scene.custom_fields[CONFIG.fieldName]
                : null;

            var numericValue = 0;

            if (
                rawValue !== null &&
                rawValue !== undefined &&
                rawValue !== ""
            ) {
                numericValue = Number(rawValue);

                if (
                    !isFinite(numericValue) ||
                    Math.floor(numericValue) !== numericValue
                ) {
                    if (CONFIG.debug) {
                        console.warn(
                            "[Performer Custom Field Counter] Ignoring non-integer scene value:",
                            rawValue,
                            "Scene:",
                            id
                        );
                    }

                    numericValue = 0;
                }
            }

            cache.set(cacheKey, {
                value: numericValue,
                loadedAt: Date.now()
            });

            if (CONFIG.debug) {
                console.log(
                    "[Performer Custom Field Counter] SCENE VALUE:",
                    scene.title,
                    "=",
                    numericValue
                );
            }

            return numericValue;
        })();

        pendingRequests.set(cacheKey, request);

        try {
            return await request;
        } finally {
            pendingRequests.delete(cacheKey);
        }
    }

    // ============================================================
    // FORMAT VOLUME
    // ============================================================

    function formatVolume(value) {
        var formatted = (value * CONFIG.volumeFactor).toFixed(2);

        formatted = formatted
            .replace(/0+$/, "")
            .replace(/\.$/, "");

        return formatted + " L";
    }

    // ============================================================
    // SVG ICON
    // ============================================================

    function VolumeIcon() {
        return React.createElement(
            "svg",
            {
                viewBox: "0 0 40 40",
                width: "14",
                height: "14",
                xmlns: "http://www.w3.org/2000/svg",
                fill: "currentColor",
                style: {
                    display: "block",
                    flexShrink: 0
                }
            },
            React.createElement("path", {
                d: "M22.855.758L7.875 7.024l12.537 9.733c2.633 2.224 6.377 2.937 9.77 1.518c4.826-2.018 7.096-7.576 5.072-12.413C33.232 1.024 27.68-1.261 22.855.758zm-9.962 17.924L2.05 10.284L.137 23.529a7.993 7.993 0 0 0 2.958 7.803a8.001 8.001 0 0 0 9.798-12.65zm15.339 7.015l-8.156-4.69l-.033 9.223c-.088 2 .904 3.98 2.75 5.041a5.462 5.462 0 0 0 7.479-2.051c1.499-2.644.589-6.013-2.04-7.523z"
            })
        );
    }

    // ============================================================
    // SHARED OVERLAY
    //
    // Performers: bottomOffset = 5
    // Scenes:     bottomOffset = 10
    // ============================================================

    function createCounterOverlay(value, bottomOffset) {
        var displayValue = value === null ? "..." : String(value);
        var volumeValue = value === null ? "..." : formatVolume(value);

        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",
                    bottom: (bottomOffset !== undefined ? bottomOffset : 5) + "px",
                    left: "5px",
                    zIndex: 100,
                    backgroundColor: "rgba(0, 0, 0, 0.85)",
                    color: "white",
                    padding: "4px 7px",
                    borderRadius: "4px",
                    fontSize: "12px",
                    lineHeight: "16px",
                    pointerEvents: "none"
                }
            },
            React.createElement(
                "div",
                {
                    style: {
                        display: "flex",
                        alignItems: "center",
                        gap: "4px",
                        fontWeight: "bold"
                    }
                },
                React.createElement(VolumeIcon, null),
                React.createElement("span", null, displayValue)
            ),
            React.createElement(
                "div",
                {
                    style: {
                        marginTop: "1px",
                        textAlign: "center",
                        fontSize: "11px",
                        lineHeight: "14px"
                    }
                },
                volumeValue
            )
        );
    }

    // ============================================================
    // PERFORMER COUNTER COMPONENT
    // ============================================================

    function CounterOverlay(props) {
        var performerId = props.performerId;

        var state = React.useState(null);
        var value = state[0];
        var setValue = state[1];

        React.useEffect(function () {
            var cancelled = false;

            async function load() {
                var total;

                try {
                    total = await getPerformerTotal(performerId);
                } catch (error) {
                    console.error(
                        "[Performer Custom Field Counter] Counter error:",
                        error
                    );

                    total = 0;
                }

                if (!cancelled) {
                    setValue(total);
                }
            }

            load();

            return function () {
                cancelled = true;
            };
        }, [performerId]);

        if (CONFIG.hideZero && value === 0) {
            return null;
        }

        // Performer offset: 5px from the bottom.
        return createCounterOverlay(value, 5);
    }

    // ============================================================
    // SCENE COUNTER COMPONENT
    // ============================================================

    function SceneCounterOverlay(props) {
        var sceneId = props.sceneId;

        var state = React.useState(null);
        var value = state[0];
        var setValue = state[1];

        React.useEffect(function () {
            var cancelled = false;

            async function load() {
                var sceneValue;

                try {
                    sceneValue = await getSceneValue(sceneId);
                } catch (error) {
                    console.error(
                        "[Performer Custom Field Counter] Scene counter error:",
                        error
                    );

                    sceneValue = 0;
                }

                if (!cancelled) {
                    setValue(sceneValue);
                }
            }

            load();

            return function () {
                cancelled = true;
            };
        }, [sceneId]);

        if (CONFIG.hideZero && value === 0) {
            return null;
        }

        // Scene offset: 10px from the bottom.
        return createCounterOverlay(value, 10);
    }

    // ============================================================
    // PERFORMER CARD PATCH
    // ============================================================

    PluginApi.patch.after("PerformerCard.Overlays", function (props, original) {
        if (!props || !props.performer || !props.performer.id) {
            return null;
        }

        return React.createElement(
            React.Fragment,
            null,
            React.createElement(CounterOverlay, {
                performerId: String(props.performer.id)
            })
        );
    });

    // ============================================================
    // SCENE CARD PATCH
    // ============================================================

    PluginApi.patch.after("SceneCard.Overlays", function (props, original) {
        if (!props || !props.scene || !props.scene.id) {
            return null;
        }

        return React.createElement(
            React.Fragment,
            null,
            React.createElement(SceneCounterOverlay, {
                sceneId: String(props.scene.id)
            })
        );
    });

    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {
        getTotal: function (performerId) {
            var cached = cache.get(String(performerId));
            return cached ? cached.value : null;
        },

        refreshPerformer: async function (performerId) {
            var id = String(performerId);
            cache.delete(id);
            return await getPerformerTotal(id);
        },

        getSceneValue: async function (sceneId) {
            var id = String(sceneId);
            var cached = cache.get("scene:" + id);

            if (cached) {
                return cached.value;
            }

            return await getSceneValue(id);
        },

        refreshScene: async function (sceneId) {
            var id = String(sceneId);
            cache.delete("scene:" + id);
            return await getSceneValue(id);
        },

        clearCache: function () {
            cache.clear();
            console.log("[Performer Custom Field Counter] Cache cleared.");
        },

        status: function () {
            var keys = Array.from(cache.keys());

            return {
                stashVersion: "0.31.1",
                fieldName: CONFIG.fieldName,
                volumeFactor: CONFIG.volumeFactor,
                cachedEntries: cache.size,
                cachedPerformers: keys.filter(function (key) {
                    return key.indexOf("scene:") !== 0;
                }).length,
                cachedScenes: keys.filter(function (key) {
                    return key.indexOf("scene:") === 0;
                }).length,
                pendingRequests: pendingRequests.size,
                reactAvailable: !!PluginApi.React
            };
        }
    };

    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log("[Performer Custom Field Counter] Plugin loaded.");
    console.log("[Performer Custom Field Counter] Target: Stash v0.31.1");
    console.log("[Performer Custom Field Counter] Custom field:", CONFIG.fieldName);
    console.log("[Performer Custom Field Counter] Volume factor:", CONFIG.volumeFactor);
    console.log("[Performer Custom Field Counter] React available:", !!PluginApi.React);
})();