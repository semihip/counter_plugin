```javascript
(function () {
    "use strict";


    // ============================================================
    // STASH VERSION
    // ============================================================

    // This plugin is specifically developed for:
    // Stash v0.31.1


    // ============================================================
    // PLUGIN API
    // ============================================================

    const PluginApi = window.PluginApi;


    if (!PluginApi) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi is not available."
        );

        return;
    }


    // React is exposed through PluginApi.React in this environment.
    const React = PluginApi.React;


    if (!React) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi.React is not available."
        );

        console.error(
            "[Performer Custom Field Counter] " +
            "Available PluginApi properties:",
            Object.keys(PluginApi)
        );

        return;
    }


    console.log(
        "[Performer Custom Field Counter] " +
        "PluginApi.React is available."
    );


    // ============================================================
    // CONFIGURATION
    // ============================================================

    const CONFIG = {

        // Name of the Stash scene custom field
        fieldName: "custom_field",

        // Number of scenes retrieved by the initial query
        pageSize: 5,

        // Number of scenes for which findScene() is called
        diagnosticSceneLimit: 5,

        // Cache duration
        cacheDuration: 5 * 60 * 1000,

        // Diagnostic mode
        diagnosticMode: true,

        // Always show zero
        hideZero: false,
    };


    // ============================================================
    // STATE
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables = {}) {

        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL query:",
            query
        );


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL variables:",
            variables
        );


        const response = await fetch(
            "/graphql",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                },

                body: JSON.stringify({
                    query: query,
                    variables: variables,
                }),
            }
        );


        let json;


        try {

            json = await response.json();

        } catch (error) {

            throw new Error(
                "Unable to parse GraphQL response. " +
                "HTTP " +
                response.status +
                " " +
                response.statusText
            );
        }


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL HTTP:",
            response.status,
            response.statusText
        );


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL raw response:",
            json
        );


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                JSON.stringify(json)
            );
        }


        if (json.errors) {

            throw new Error(
                "GraphQL errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD DATA
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        if (
            !forceRefresh &&
            loadedAt > 0 &&
            Date.now() - loadedAt <
                CONFIG.cacheDuration
        ) {

            return totalsByPerformer;
        }


        if (loadingPromise) {

            return loadingPromise;
        }


        loadingPromise = (async function () {

            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "START PERFORMER DIAGNOSTIC"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Target Stash version: 0.31.1"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Custom field:",
                CONFIG.fieldName
            );


            // ====================================================
            // STEP 1
            // Get a small list of scenes.
            //
            // We deliberately do NOT request performers here.
            // ====================================================

            const scenesQuery = `
                query PerformerCustomFieldCounter(
                    $filter: FindFilterType
                ) {
                    findScenes(
                        filter: $filter
                    ) {
                        count

                        scenes {
                            id
                            title
                        }
                    }
                }
            `;


            let scenesData;


            try {

                scenesData = await graphql(
                    scenesQuery,
                    {
                        filter: {
                            page: 1,
                            per_page: CONFIG.pageSize,
                        },
                    }
                );

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "ERROR while retrieving scenes:",
                    error
                );


                totalsByPerformer =
                    new Map();


                return totalsByPerformer;
            }


            // ====================================================
            // STEP 2
            // Validate scene result.
            // ====================================================

            const findScenes =
                scenesData?.findScenes;


            if (!findScenes) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "findScenes is missing."
                );


                totalsByPerformer =
                    new Map();


                return totalsByPerformer;
            }


            const scenes =
                findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] " +
                "Total scenes in database:",
                findScenes.count
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Scenes returned:",
                scenes.length
            );


            if (scenes.length === 0) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "No scenes were returned."
                );


                totalsByPerformer =
                    new Map();


                return totalsByPerformer;
            }


            // ====================================================
            // STEP 3
            // Test findScene() individually.
            //
            // This is the important diagnostic.
            // ====================================================

            const sceneLimit =
                Math.min(
                    CONFIG.diagnosticSceneLimit,
                    scenes.length
                );


            console.log(
                "[Performer Custom Field Counter] " +
                "Testing findScene() on",
                sceneLimit,
                "scene(s)."
            );


            const singleSceneQuery = `
                query PerformerCustomFieldCounterSingleScene(
                    $id: ID
                ) {
                    findScene(
                        id: $id
                    ) {
                        id
                        title

                        performers {
                            id
                            name
                        }
                    }
                }
            `;


            for (
                let index = 0;
                index < sceneLimit;
                index++
            ) {

                const scene =
                    scenes[index];


                console.log(
                    "------------------------------------------------"
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "TEST SCENE #" +
                    (index + 1)
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scene ID:",
                    scene.id
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scene title:",
                    scene.title
                );


                let singleSceneData;


                try {

                    singleSceneData =
                        await graphql(
                            singleSceneQuery,
                            {
                                id: String(scene.id),
                            }
                        );

                } catch (error) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "ERROR retrieving scene " +
                        scene.id +
                        ":",
                        error
                    );

                    continue;
                }


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene DATA:",
                    singleSceneData
                );


                const singleScene =
                    singleSceneData?.findScene;


                if (!singleScene) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "findScene returned null for ID:",
                        scene.id
                    );

                    continue;
                }


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene ID:",
                    singleScene.id
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene TITLE:",
                    singleScene.title
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene PERFORMERS:",
                    singleScene.performers
                );


                if (
                    Array.isArray(
                        singleScene.performers
                    )
                ) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Performer count:",
                        singleScene.performers.length
                    );


                    if (
                        singleScene.performers.length === 0
                    ) {

                        console.warn(
                            "[Performer Custom Field Counter] " +
                            "WARNING: findScene() returned " +
                            "ZERO performers for this scene."
                        );

                    }


                    singleScene.performers.forEach(
                        function (performer, performerIndex) {

                            console.log(
                                "[Performer Custom Field Counter] " +
                                "Performer #" +
                                (performerIndex + 1) +
                                ":",
                                {
                                    id: performer?.id,
                                    name: performer?.name,
                                }
                            );
                        }
                    );

                } else {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "performers is NOT an array:",
                        singleScene.performers
                    );
                }
            }


            // ====================================================
            // STEP 4
            // For now, do not aggregate anything.
            //
            // This diagnostic is only intended to establish
            // whether findScene() correctly returns performers.
            // ====================================================

            totalsByPerformer =
                new Map();


            loadedAt =
                Date.now();


            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "END PERFORMER DIAGNOSTIC"
            );


            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // COUNTER OVERLAY
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] =
            React.useState(null);


        React.useEffect(
            function () {

                let cancelled = false;


                async function load() {

                    try {

                        const totals =
                            await loadTotals();


                        if (cancelled) {
                            return;
                        }


                        const total =
                            totals.get(
                                String(performerId)
                            ) || 0;


                        setValue(total);

                    } catch (error) {

                        console.error(
                            "[Performer Custom Field Counter] " +
                            "Counter error:",
                            error
                        );


                        if (!cancelled) {

                            setValue(0);
                        }
                    }
                }


                load();


                return function () {

                    cancelled = true;
                };

            },
            [performerId]
        );


        if (
            CONFIG.hideZero &&
            value === 0
        ) {

            return null;
        }


        const displayValue =
            value === null
                ? "..."
                : String(value);


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",

                    top: "5px",

                    right: "5px",

                    zIndex: 100,

                    backgroundColor:
                        "rgba(0, 0, 0, 0.85)",

                    color: "white",

                    padding: "3px 7px",

                    borderRadius: "4px",

                    fontSize: "12px",

                    fontWeight: "bold",

                    lineHeight: "16px",

                    pointerEvents: "none",
                },
            },
            displayValue
        );
    }


    // ============================================================
    // PATCH PERFORMER CARD
    // ============================================================

    PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            const performer =
                props?.performer;


            if (!performer?.id) {

                return null;
            }


            const counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            String(performer.id),
                    }
                );


            // Diagnostic mode:
            // only display our counter.
            if (CONFIG.diagnosticMode) {

                return React.createElement(
                    React.Fragment,
                    null,
                    counter
                );
            }


            return React.createElement(
                React.Fragment,
                null,
                original,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            return await loadTotals(true);
        },


        async diagnostic() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            return await loadTotals(true);
        },


        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        clearCache() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        status() {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                loadedAt:
                    loadedAt,

                cacheEntries:
                    totalsByPerformer.size,

                diagnosticMode:
                    CONFIG.diagnosticMode,

                reactAvailable:
                    !!PluginApi.React,
            };
        },
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "PluginApi.React:",
        PluginApi.React
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "React available:",
        !!PluginApi.React
    );


})();
```
