(function () {
    "use strict";

    // ============================================================
    // CONFIGURATION
    // ============================================================

    const CONFIG = {
        fieldName: "custom_field",
        pageSize: 10,
        cacheDuration: 5 * 60 * 1000,

        // Diagnostic uniquement
        diagnosticMode: true,

        // Toujours afficher le compteur
        hideZero: false,
    };


    // ============================================================
    // GLOBAL STATE
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables = {}) {

        console.log(
            "[Performer Custom Field Counter] GraphQL query:",
            query
        );

        console.log(
            "[Performer Custom Field Counter] GraphQL variables:",
            variables
        );


        const response = await fetch("/graphql", {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });


        const json = await response.json();


        console.log(
            "[Performer Custom Field Counter] HTTP status:",
            response.status,
            response.statusText
        );


        console.log(
            "[Performer Custom Field Counter] RAW response:",
            json
        );


        if (!response.ok) {

            const details =
                json?.errors
                    ? JSON.stringify(json.errors)
                    : JSON.stringify(json);


            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                details
            );
        }


        if (json.errors) {

            console.error(
                "[Performer Custom Field Counter] GraphQL errors:",
                json.errors
            );


            throw new Error(
                "GraphQL returned errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD SCENES - DIAGNOSTIC VERSION
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        if (
            !forceRefresh &&
            loadedAt > 0 &&
            Date.now() - loadedAt < CONFIG.cacheDuration
        ) {

            return totalsByPerformer;
        }


        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async function () {

            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "START DIAGNOSTIC"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Target Stash version: 0.31.1"
            );


            // ----------------------------------------------------
            // IMPORTANT
            //
            // Pour ce test, on ne demande PAS custom_fields.
            //
            // On vérifie d'abord que findScenes fonctionne
            // correctement dans Stash v0.31.1.
            // ----------------------------------------------------

            const query = `
                query PerformerCustomFieldCounter(
                    $filter: FindFilterType
                ) {
                    findScenes(
                        filter: $filter
                    ) {
                        count
                        scenes {
                            id
                            title

                            performers {
                                id
                                name
                            }
                        }
                    }
                }
            `;


            let data;


            try {

                data = await graphql(
                    query,
                    {
                        filter: {
                            page: 1,
                            per_page: CONFIG.pageSize,
                        },
                    }
                );

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "ERROR:",
                    error
                );


                totalsByPerformer = new Map();


                return totalsByPerformer;
            }


            // ----------------------------------------------------
            // GRAPHQL RESULT
            // ----------------------------------------------------

            console.log(
                "[Performer Custom Field Counter] " +
                "GRAPHQL DATA:",
                data
            );


            const findScenes =
                data?.findScenes;


            console.log(
                "[Performer Custom Field Counter] " +
                "findScenes:",
                findScenes
            );


            if (!findScenes) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "findScenes is empty."
                );


                totalsByPerformer = new Map();


                return totalsByPerformer;
            }


            const scenes =
                findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] " +
                "Number of scenes returned:",
                scenes.length
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Total scenes:",
                findScenes.count
            );


            // ----------------------------------------------------
            // DISPLAY SCENES
            // ----------------------------------------------------

            scenes.forEach(function (scene, index) {

                console.log(
                    "------------------------------------------------"
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "SCENE #" +
                    (index + 1)
                );


                console.log(
                    "ID:",
                    scene.id
                );


                console.log(
                    "Title:",
                    scene.title
                );


                console.log(
                    "Performers:",
                    scene.performers
                );


                if (Array.isArray(scene.performers)) {

                    scene.performers.forEach(
                        function (performer, performerIndex) {

                            console.log(
                                "  Performer #" +
                                (performerIndex + 1) +
                                ":",
                                {
                                    id: performer?.id,
                                    name: performer?.name,
                                }
                            );
                        }
                    );
                }

            });


            // ----------------------------------------------------
            // NO AGGREGATION YET
            // ----------------------------------------------------

            totalsByPerformer = new Map();

            loadedAt = Date.now();


            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "END DIAGNOSTIC"
            );


            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // COUNTER OVERLAY
    //
    // IMPORTANT:
    // React is intentionally used directly here because this is
    // the mechanism that was already confirmed to work in the
    // original Stash v0.31.1 version.
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] = React.useState(null);


        React.useEffect(function () {

            let cancelled = false;


            async function load() {

                try {

                    const totals =
                        await loadTotals();


                    if (cancelled) {
                        return;
                    }


                    const total =
                        totals.get(
                            String(performerId)
                        ) || 0;


                    setValue(total);

                } catch (error) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "Counter error:",
                        error
                    );


                    if (!cancelled) {
                        setValue(0);
                    }
                }
            }


            load();


            return function () {
                cancelled = true;
            };

        }, [performerId]);


        if (CONFIG.hideZero && value === 0) {
            return null;
        }


        const displayValue =
            value === null
                ? "..."
                : String(value);


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",

                    top: "5px",

                    right: "5px",

                    zIndex: 100,

                    backgroundColor:
                        "rgba(0, 0, 0, 0.85)",

                    color: "white",

                    padding: "3px 7px",

                    borderRadius: "4px",

                    fontSize: "12px",

                    fontWeight: "bold",

                    lineHeight: "16px",

                    pointerEvents: "none",
                },
            },

            displayValue
        );
    }


    // ============================================================
    // PATCH PERFORMER CARD
    // ============================================================

    window.PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            const performer =
                props?.performer;


            if (!performer?.id) {
                return null;
            }


            const counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            String(performer.id),
                    }
                );


            // ----------------------------------------------------
            // DIAGNOSTIC MODE
            //
            // Do NOT return original.
            // This was the version that successfully displayed 0.
            // ----------------------------------------------------

            if (CONFIG.diagnosticMode) {

                return React.createElement(
                    React.Fragment,
                    null,
                    counter
                );
            }


            return React.createElement(
                React.Fragment,
                null,
                original,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            totalsByPerformer =
                new Map();

            loadedAt = 0;


            return await loadTotals(true);
        },


        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        clearCache() {

            totalsByPerformer =
                new Map();

            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        async diagnostic() {

            totalsByPerformer =
                new Map();

            loadedAt = 0;


            return await loadTotals(true);
        },


        status() {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                loadedAt:
                    loadedAt,

                cacheEntries:
                    totalsByPerformer.size,

                diagnosticMode:
                    CONFIG.diagnosticMode,
            };
        },
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target version: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Custom field:",
        CONFIG.fieldName
    );

})();