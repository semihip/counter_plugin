(function () {
    "use strict";

    // ============================================================
    // CONFIGURATION
    // ============================================================

    const CONFIG = {
        fieldName: "custom_field",
        pageSize: 10,
        diagnosticMode: true,
        showCounter: true,
    };


    // ============================================================
    // REACT
    // ============================================================

    const React = window.React;


    if (!React) {

        console.error(
            "[Performer Custom Field Counter] React is not available on window."
        );

        return;
    }


    // ============================================================
    // ÉTAT GLOBAL
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables = {}) {

        console.log(
            "[Performer Custom Field Counter] GraphQL query:",
            query
        );

        console.log(
            "[Performer Custom Field Counter] GraphQL variables:",
            variables
        );


        const response = await fetch("/graphql", {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });


        const json = await response.json();


        console.log(
            "[Performer Custom Field Counter] HTTP response:",
            response.status,
            response.statusText
        );


        console.log(
            "[Performer Custom Field Counter] RAW GraphQL response:",
            json
        );


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText
            );
        }


        if (json.errors) {

            console.error(
                "[Performer Custom Field Counter] GraphQL errors:",
                json.errors
            );

            throw new Error(
                "GraphQL returned errors."
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD SCENES
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async () => {

            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] START DIAGNOSTIC"
            );

            console.log(
                "[Performer Custom Field Counter] Field name:",
                CONFIG.fieldName
            );


            const query = `
                query PerformerCustomFieldCounter(
                    $filter: FindFilterType
                ) {
                    findScenes(
                        filter: $filter
                    ) {
                        count
                        pages

                        scenes {
                            id
                            title
                            custom_fields

                            performers {
                                id
                                name
                            }
                        }
                    }
                }
            `;


            let data;


            try {

                data = await graphql(query, {
                    filter: {
                        page: 1,
                        per_page: CONFIG.pageSize,
                    },
                });

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] ERROR:",
                    error
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            // ----------------------------------------------------
            // RESULTAT COMPLET
            // ----------------------------------------------------

            console.log(
                "[Performer Custom Field Counter] DATA:",
                data
            );


            const findScenes = data?.findScenes;


            console.log(
                "[Performer Custom Field Counter] findScenes:",
                findScenes
            );


            if (!findScenes) {

                console.error(
                    "[Performer Custom Field Counter] findScenes is empty."
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            const scenes = findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] Number of scenes returned:",
                scenes.length
            );


            console.log(
                "[Performer Custom Field Counter] Total scenes:",
                findScenes.count
            );


            console.log(
                "[Performer Custom Field Counter] Number of pages:",
                findScenes.pages
            );


            // ----------------------------------------------------
            // DÉTAIL DE CHAQUE SCÈNE
            // ----------------------------------------------------

            scenes.forEach((scene, index) => {

                console.log(
                    "------------------------------------------------"
                );

                console.log(
                    "[Performer Custom Field Counter] SCENE #" +
                    (index + 1)
                );


                console.log(
                    "ID:",
                    scene.id
                );


                console.log(
                    "Title:",
                    scene.title
                );


                console.log(
                    "custom_fields:",
                    scene.custom_fields
                );


                console.log(
                    "custom_fields type:",
                    typeof scene.custom_fields
                );


                let rawValue;


                if (
                    scene.custom_fields &&
                    typeof scene.custom_fields === "object"
                ) {

                    rawValue =
                        scene.custom_fields[CONFIG.fieldName];
                }


                console.log(
                    "custom_field [" +
                    CONFIG.fieldName +
                    "]:",
                    rawValue
                );


                console.log(
                    "custom_field type:",
                    typeof rawValue
                );


                console.log(
                    "performers:",
                    scene.performers
                );


                console.log(
                    "performers type:",
                    typeof scene.performers
                );


                if (Array.isArray(scene.performers)) {

                    console.log(
                        "performer count:",
                        scene.performers.length
                    );


                    scene.performers.forEach(
                        (performer, performerIndex) => {

                            console.log(
                                "performer #" +
                                (performerIndex + 1) +
                                ":",
                                {
                                    id: performer?.id,
                                    name: performer?.name,
                                }
                            );
                        }
                    );

                } else {

                    console.warn(
                        "[Performer Custom Field Counter] performers is NOT an array:",
                        scene.performers
                    );
                }

            });


            // ----------------------------------------------------
            // POUR L'INSTANT : AUCUNE AGRÉGATION
            // ----------------------------------------------------

            totalsByPerformer = new Map();

            loadedAt = Date.now();


            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] END DIAGNOSTIC"
            );

            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // COUNTER OVERLAY
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] = React.useState(null);


        React.useEffect(() => {

            let cancelled = false;


            async function load() {

                const totals = await loadTotals();


                if (cancelled) {
                    return;
                }


                const total =
                    totals.get(String(performerId)) || 0;


                setValue(total);
            }


            load();


            return () => {
                cancelled = true;
            };

        }, [performerId]);


        if (!CONFIG.showCounter) {
            return null;
        }


        const displayValue =
            value === null
                ? "..."
                : String(value);


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",
                    top: "5px",
                    right: "5px",

                    zIndex: 100,

                    backgroundColor: "rgba(0, 0, 0, 0.85)",
                    color: "white",

                    padding: "3px 7px",

                    borderRadius: "4px",

                    fontSize: "12px",
                    fontWeight: "bold",

                    lineHeight: "16px",

                    pointerEvents: "none",
                },
            },
            displayValue
        );
    }


    // ============================================================
    // PATCH PERFORMER CARD
    // ============================================================

    window.PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            const performer = props?.performer;


            if (!performer?.id) {
                return null;
            }


            const counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId: String(performer.id),
                    }
                );


            // Ne pas réinjecter "original".
            // Cela avait provoqué l'erreur React précédente.

            return React.createElement(
                React.Fragment,
                null,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            totalsByPerformer = new Map();

            loadedAt = 0;

            return await loadTotals(true);
        },


        getTotal(performerId) {

            return totalsByPerformer.get(
                String(performerId)
            ) || 0;
        },


        clearCache() {

            totalsByPerformer = new Map();

            loadedAt = 0;

            console.log(
                "[Performer Custom Field Counter] Cache cleared."
            );
        },


        status() {

            return {
                fieldName: CONFIG.fieldName,
                loadedAt: loadedAt,
                cacheEntries: totalsByPerformer.size,
                diagnosticMode: CONFIG.diagnosticMode,
                reactAvailable: !!window.React,
            };
        },


        async diagnostic() {

            console.log(
                "[Performer Custom Field Counter] Running diagnostic..."
            );

            totalsByPerformer = new Map();

            loadedAt = 0;

            return await loadTotals(true);
        },
    };


    // ============================================================
    // INITIAL MESSAGE
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] Plugin loaded."
    );

    console.log(
        "[Performer Custom Field Counter] Stash version: 0.31.1"
    );

    console.log(
        "[Performer Custom Field Counter] Custom field:",
        CONFIG.fieldName
    );

    console.log(
        "[Performer Custom Field Counter] React available:",
        !!window.React
    );

})();