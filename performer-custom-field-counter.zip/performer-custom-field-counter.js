(function () {
    "use strict";


    // ============================================================
    // STASH VERSION
    // ============================================================

    // Developed specifically for:
    // Stash v0.31.1


    // ============================================================
    // PLUGIN API
    // ============================================================

    var PluginApi = window.PluginApi;


    if (!PluginApi) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi is not available."
        );

        return;
    }


    // React is explicitly obtained from PluginApi.
    var React = PluginApi.React;


    if (!React) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi.React is not available."
        );

        return;
    }


    // ============================================================
    // CONFIGURATION
    // ============================================================

    var CONFIG = {

        // Scene custom field to sum.
        fieldName: "custom_field",

        // Cache duration.
        cacheDuration: 5 * 60 * 1000,

        // Show 0 when the performer has no matching value.
        hideZero: false,

        // Set to true if you want additional console logging.
        debug: true
    };


    // ============================================================
    // CACHE
    // ============================================================

    // performerId -> {
    //     value: number,
    //     loadedAt: number
    // }
    var cache = new Map();


    // performerId -> Promise
    //
    // This prevents multiple cards for the same performer
    // from starting multiple simultaneous requests.
    var pendingRequests = new Map();


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables) {

        if (!variables) {
            variables = {};
        }


        if (CONFIG.debug) {

            console.log(
                "[Performer Custom Field Counter] " +
                "GraphQL variables:",
                variables
            );
        }


        var response = await fetch(
            "/graphql",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    query: query,
                    variables: variables
                })
            }
        );


        var json;


        try {

            json = await response.json();

        } catch (error) {

            throw new Error(
                "Unable to parse GraphQL response. HTTP " +
                response.status +
                " " +
                response.statusText
            );
        }


        if (CONFIG.debug) {

            console.log(
                "[Performer Custom Field Counter] " +
                "GraphQL HTTP:",
                response.status,
                response.statusText
            );
        }


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                JSON.stringify(json)
            );
        }


        if (json.errors) {

            throw new Error(
                "GraphQL errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // GET PERFORMER TOTAL
    // ============================================================

    async function getPerformerTotal(performerId) {

        performerId =
            String(performerId);


        // --------------------------------------------------------
        // CACHE
        // --------------------------------------------------------

        var cached =
            cache.get(performerId);


        if (cached) {

            var age =
                Date.now() - cached.loadedAt;


            if (
                age < CONFIG.cacheDuration
            ) {

                return cached.value;
            }


            cache.delete(performerId);
        }


        // --------------------------------------------------------
        // EXISTING REQUEST
        // --------------------------------------------------------

        if (
            pendingRequests.has(performerId)
        ) {

            return pendingRequests.get(
                performerId
            );
        }


        // --------------------------------------------------------
        // LOAD
        // --------------------------------------------------------

        var request =
            (async function () {

                if (CONFIG.debug) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Loading performer:",
                        performerId
                    );
                }


                // ------------------------------------------------
                // IMPORTANT
                //
                // We query the performer and navigate:
                //
                // performer
                //     -> scenes
                //          -> custom_fields
                //
                // We deliberately do NOT use:
                //
                // scene -> performers
                //
                // because that relation was returning empty
                // results in our tests.
                // ------------------------------------------------

                var query =
                    "query PerformerCustomFieldCounter($id: ID!) {" +
                    " findPerformer(id: $id) {" +
                    "   id" +
                    "   name" +
                    "   scene_count" +
                    "   scenes {" +
                    "     id" +
                    "     custom_fields" +
                    "   }" +
                    " }" +
                    "}";


                var data;


                try {

                    data =
                        await graphql(
                            query,
                            {
                                id: performerId
                            }
                        );

                } catch (error) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "Error loading performer " +
                        performerId +
                        ":",
                        error
                    );

                    return 0;
                }


                if (
                    !data ||
                    !data.findPerformer
                ) {

                    console.warn(
                        "[Performer Custom Field Counter] " +
                        "Performer not found:",
                        performerId
                    );

                    return 0;
                }


                var performer =
                    data.findPerformer;


                var scenes =
                    performer.scenes || [];


                if (CONFIG.debug) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Performer:",
                        performer.name,
                        "(" + performer.id + ")"
                    );

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Scene count:",
                        performer.scene_count
                    );

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Scenes returned:",
                        scenes.length
                    );
                }


                // ------------------------------------------------
                // SUM CUSTOM FIELD
                // ------------------------------------------------

                var total = 0;


                var sceneIndex;


                for (
                    sceneIndex = 0;
                    sceneIndex < scenes.length;
                    sceneIndex++
                ) {

                    var scene =
                        scenes[sceneIndex];


                    if (
                        !scene ||
                        !scene.custom_fields
                    ) {

                        continue;
                    }


                    var rawValue =
                        scene.custom_fields[
                            CONFIG.fieldName
                        ];


                    // Ignore missing values.
                    if (
                        rawValue === null ||
                        rawValue === undefined ||
                        rawValue === ""
                    ) {

                        continue;
                    }


                    // Convert to number.
                    var numericValue =
                        Number(rawValue);


                    // Only accept integers.
                    if (
                        !isFinite(numericValue) ||
                        Math.floor(numericValue) !== numericValue
                    ) {

                        if (CONFIG.debug) {

                            console.warn(
                                "[Performer Custom Field Counter] " +
                                "Ignoring non-integer value:",
                                rawValue,
                                "Scene:",
                                scene.id
                            );
                        }

                        continue;
                    }


                    total +=
                        numericValue;
                }


                // ------------------------------------------------
                // CACHE RESULT
                // ------------------------------------------------

                cache.set(
                    performerId,
                    {
                        value: total,
                        loadedAt: Date.now()
                    }
                );


                if (CONFIG.debug) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "TOTAL:",
                        performer.name,
                        "=",
                        total
                    );
                }


                return total;

            })();


        pendingRequests.set(
            performerId,
            request
        );


        try {

            return await request;

        } finally {

            pendingRequests.delete(
                performerId
            );
        }
    }


    // ============================================================
    // COUNTER COMPONENT
    // ============================================================

    function CounterOverlay(props) {

        var performerId =
            props.performerId;


        var state =
            React.useState(null);


        var value =
            state[0];


        var setValue =
            state[1];


        React.useEffect(
            function () {

                var cancelled = false;


                async function load() {

                    try {

                        var total =
                            await getPerformerTotal(
                                performerId
                            );


                        if (cancelled) {
                            return;
                        }


                        setValue(total);

                    } catch (error) {

                        console.error(
                            "[Performer Custom Field Counter] " +
                            "Counter error:",
                            error
                        );


                        if (!cancelled) {
                            setValue(0);
                        }
                    }
                }


                load();


                return function () {

                    cancelled = true;
                };

            },
            [performerId]
        );


        // --------------------------------------------------------
        // Hide zero if configured.
        // --------------------------------------------------------

        if (
            CONFIG.hideZero &&
            value === 0
        ) {

            return null;
        }


        var displayValue;


        if (value === null) {

            displayValue = "...";

        } else {

            displayValue =
                String(value);
        }


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",

                    top: "5px",

                    right: "5px",

                    zIndex: 100,

                    backgroundColor:
                        "rgba(0, 0, 0, 0.85)",

                    color: "white",

                    padding: "3px 7px",

                    borderRadius: "4px",

                    fontSize: "12px",

                    fontWeight: "bold",

                    lineHeight: "16px",

                    pointerEvents: "none"
                }
            },
            displayValue
        );
    }


    // ============================================================
    // PERFORMER CARD PATCH
    // ============================================================

    PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            if (
                !props ||
                !props.performer ||
                !props.performer.id
            ) {

                return null;
            }


            var performerId =
                String(
                    props.performer.id
                );


            var counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            performerId
                    }
                );


            // ----------------------------------------------------
            // Keep the existing performer overlays.
            // ----------------------------------------------------

            return React.createElement(
                React.Fragment,
                null,
                original,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG / PUBLIC API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        // --------------------------------------------------------
        // Get a performer's current cached value.
        // --------------------------------------------------------

        getTotal: function (performerId) {

            var id =
                String(performerId);


            var cached =
                cache.get(id);


            if (!cached) {
                return null;
            }


            return cached.value;
        },


        // --------------------------------------------------------
        // Force reload for one performer.
        // --------------------------------------------------------

        refreshPerformer: async function (
            performerId
        ) {

            var id =
                String(performerId);


            cache.delete(id);


            return await getPerformerTotal(
                id
            );
        },


        // --------------------------------------------------------
        // Clear complete cache.
        // --------------------------------------------------------

        clearCache: function () {

            cache.clear();

            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        // --------------------------------------------------------
        // Get plugin status.
        // --------------------------------------------------------

        status: function () {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                cachedPerformers:
                    cache.size,

                pendingRequests:
                    pendingRequests.size,

                reactAvailable:
                    !!PluginApi.React
            };
        }
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Custom field:",
        CONFIG.fieldName
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "React available:",
        !!PluginApi.React
    );

})();