(function () {
    "use strict";


    // ============================================================
    // STASH VERSION
    // ============================================================

    // Target:
    // Stash v0.31.1


    // ============================================================
    // PLUGIN API
    // ============================================================

    var PluginApi = window.PluginApi;


    if (!PluginApi) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi is not available."
        );

        return;
    }


    var React = PluginApi.React;


    if (!React) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi.React is not available."
        );

        return;
    }


    // ============================================================
    // CONFIGURATION
    // ============================================================

    var CONFIG = {

        fieldName: "custom_field",

        cacheDuration: 5 * 60 * 1000,

        hideZero: false,

        debug: true
    };


    // ============================================================
    // CACHE
    // ============================================================

    var cache = new Map();

    var pendingRequests = new Map();


    // ============================================================
    // GRAPHQL
    // ============================================================

    async function graphql(query, variables) {

        if (!variables) {
            variables = {};
        }


        var response = await fetch(
            "/graphql",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    query: query,
                    variables: variables
                })
            }
        );


        var json;


        try {

            json = await response.json();

        } catch (error) {

            throw new Error(
                "Unable to parse GraphQL response. HTTP " +
                response.status
            );
        }


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                JSON.stringify(json)
            );
        }


        if (json.errors) {

            throw new Error(
                "GraphQL errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD PERFORMER TOTAL
    // ============================================================

    async function getPerformerTotal(performerId) {

        var id =
            String(performerId);


        // --------------------------------------------------------
        // Check cache.
        // --------------------------------------------------------

        var cached =
            cache.get(id);


        if (cached) {

            var age =
                Date.now() -
                cached.loadedAt;


            if (
                age < CONFIG.cacheDuration
            ) {

                if (CONFIG.debug) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "CACHE:",
                        id,
                        cached.value
                    );
                }


                return cached.value;
            }


            cache.delete(id);
        }


        // --------------------------------------------------------
        // Avoid duplicate requests.
        // --------------------------------------------------------

        if (
            pendingRequests.has(id)
        ) {

            return pendingRequests.get(id);
        }


        // --------------------------------------------------------
        // Query.
        // --------------------------------------------------------

        var request =
            (async function () {

                console.log(
                    "[Performer Custom Field Counter] " +
                    "Loading performer:",
                    id
                );


                var query =
                    "query PerformerCustomFieldCounter($id: ID!) {" +
                    " findPerformer(id: $id) {" +
                    "   id" +
                    "   name" +
                    "   scene_count" +
                    "   scenes {" +
                    "     id" +
                    "     custom_fields" +
                    "   }" +
                    " }" +
                    "}";


                var data;


                try {

                    data =
                        await graphql(
                            query,
                            {
                                id: id
                            }
                        );

                } catch (error) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "GraphQL error for performer " +
                        id +
                        ":",
                        error
                    );


                    return 0;
                }


                if (
                    !data ||
                    !data.findPerformer
                ) {

                    console.warn(
                        "[Performer Custom Field Counter] " +
                        "Performer not found:",
                        id
                    );


                    return 0;
                }


                var performer =
                    data.findPerformer;


                var scenes =
                    performer.scenes || [];


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Performer:",
                    performer.name
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scene count:",
                    performer.scene_count
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scenes returned:",
                    scenes.length
                );


                // ------------------------------------------------
                // SUM
                // ------------------------------------------------

                var total = 0;


                var sceneIndex;


                for (
                    sceneIndex = 0;
                    sceneIndex < scenes.length;
                    sceneIndex++
                ) {

                    var scene =
                        scenes[sceneIndex];


                    if (
                        !scene ||
                        !scene.custom_fields
                    ) {

                        continue;
                    }


                    var rawValue =
                        scene.custom_fields[
                            CONFIG.fieldName
                        ];


                    if (
                        rawValue === null ||
                        rawValue === undefined ||
                        rawValue === ""
                    ) {

                        continue;
                    }


                    var numericValue =
                        Number(rawValue);


                    if (
                        !isFinite(numericValue) ||
                        Math.floor(numericValue) !== numericValue
                    ) {

                        console.warn(
                            "[Performer Custom Field Counter] " +
                            "Ignoring non-integer value:",
                            rawValue,
                            "Scene:",
                            scene.id
                        );


                        continue;
                    }


                    total +=
                        numericValue;
                }


                // ------------------------------------------------
                // Save cache.
                // ------------------------------------------------

                cache.set(
                    id,
                    {
                        value: total,
                        loadedAt: Date.now()
                    }
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "TOTAL:",
                    performer.name,
                    "=",
                    total
                );


                return total;

            })();


        pendingRequests.set(
            id,
            request
        );


        try {

            return await request;

        } finally {

            pendingRequests.delete(id);
        }
    }


    // ============================================================
    // COUNTER COMPONENT
    // ============================================================

    function CounterOverlay(props) {

        var performerId =
            props.performerId;


        var state =
            React.useState(null);


        var value =
            state[0];


        var setValue =
            state[1];


        React.useEffect(
            function () {

                var cancelled = false;


                async function load() {

                    var total;


                    try {

                        total =
                            await getPerformerTotal(
                                performerId
                            );

                    } catch (error) {

                        console.error(
                            "[Performer Custom Field Counter] " +
                            "Counter error:",
                            error
                        );


                        total = 0;
                    }


                    if (!cancelled) {

                        setValue(total);
                    }
                }


                load();


                return function () {

                    cancelled = true;
                };

            },
            [performerId]
        );


        if (
            CONFIG.hideZero &&
            value === 0
        ) {

            return null;
        }


        var displayValue =
            value === null
                ? "..."
                : String(value);


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",
                    top: "5px",
                    right: "5px",
                    zIndex: 100,
                    backgroundColor: "rgba(0, 0, 0, 0.85)",
                    color: "white",
                    padding: "3px 7px",
                    borderRadius: "4px",
                    fontSize: "12px",
                    fontWeight: "bold",
                    lineHeight: "16px",
                    pointerEvents: "none"
                }
            },
            displayValue
        );
    }


    // ============================================================
    // PERFORMER CARD PATCH
    // ============================================================

    PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            if (
                !props ||
                !props.performer ||
                !props.performer.id
            ) {

                return null;
            }


            var performerId =
                String(
                    props.performer.id
                );


            var counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId: performerId
                    }
                );


            // ====================================================
            // IMPORTANT DIAGNOSTIC MODE
            //
            // DO NOT return "original".
            //
            // We already know that "original" can trigger
            // React error #31 in this patch point.
            //
            // The objective here is only to validate:
            //
            // Performer card
            //       |
            //       +--> performer ID
            //              |
            //              +--> findPerformer
            //                     |
            //                     +--> scenes
            //                            |
            //                            +--> custom_fields
            //
            // ====================================================

            return React.createElement(
                React.Fragment,
                null,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        getTotal: function (performerId) {

            var id =
                String(performerId);


            var cached =
                cache.get(id);


            if (!cached) {

                return null;
            }


            return cached.value;
        },


        refreshPerformer: async function (
            performerId
        ) {

            var id =
                String(performerId);


            cache.delete(id);


            return await getPerformerTotal(
                id
            );
        },


        clearCache: function () {

            cache.clear();


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        status: function () {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                cachedPerformers:
                    cache.size,

                pendingRequests:
                    pendingRequests.size,

                reactAvailable:
                    !!PluginApi.React
            };
        }
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Custom field:",
        CONFIG.fieldName
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "React available:",
        !!PluginApi.React
    );

})();