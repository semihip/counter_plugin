(function () {
    "use strict";

    // ============================================================
    // STASH VERSION
    // ============================================================

    // This plugin is specifically designed for:
    // Stash v0.31.1


    // ============================================================
    // CONFIGURATION
    // ============================================================

    const CONFIG = {
        fieldName: "custom_field",

        // Number of scenes to retrieve for diagnostics
        pageSize: 10,

        // Keep the counter visible
        showCounter: true,

        // Diagnostic mode
        diagnosticMode: true,
    };


    // ============================================================
    // STATE
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GRAPHQL
    // ============================================================

    async function graphql(query, variables = {}) {

        console.log(
            "[Performer Custom Field Counter] GraphQL query:",
            query
        );

        console.log(
            "[Performer Custom Field Counter] GraphQL variables:",
            variables
        );


        const response = await fetch("/graphql", {
            method: "POST",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });


        const json = await response.json();


        console.log(
            "[Performer Custom Field Counter] HTTP status:",
            response.status
        );


        console.log(
            "[Performer Custom Field Counter] RAW GraphQL response:",
            json
        );


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText
            );
        }


        if (json.errors) {

            console.error(
                "[Performer Custom Field Counter] GraphQL errors:",
                json.errors
            );

            throw new Error(
                "GraphQL returned errors."
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD SCENES
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async function () {

            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] START"
            );

            console.log(
                "[Performer Custom Field Counter] Stash target: v0.31.1"
            );

            console.log(
                "[Performer Custom Field Counter] Field:",
                CONFIG.fieldName
            );


            const query = `
                query PerformerCustomFieldCounter(
                    $filter: FindFilterType
                ) {
                    findScenes(
                        filter: $filter
                    ) {
                        count
                        pages

                        scenes {
                            id
                            title
                            custom_fields

                            performers {
                                id
                                name
                            }
                        }
                    }
                }
            `;


            let data;


            try {

                data = await graphql(
                    query,
                    {
                        filter: {
                            page: 1,
                            per_page: CONFIG.pageSize,
                        },
                    }
                );

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] ERROR:",
                    error
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            // ----------------------------------------------------
            // FIND SCENES
            // ----------------------------------------------------

            console.log(
                "[Performer Custom Field Counter] DATA:",
                data
            );


            const findScenes =
                data &&
                data.findScenes;


            console.log(
                "[Performer Custom Field Counter] findScenes:",
                findScenes
            );


            if (!findScenes) {

                console.error(
                    "[Performer Custom Field Counter] No findScenes result."
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            const scenes =
                findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] Scenes returned:",
                scenes.length
            );


            console.log(
                "[Performer Custom Field Counter] Total scenes:",
                findScenes.count
            );


            console.log(
                "[Performer Custom Field Counter] Pages:",
                findScenes.pages
            );


            // ----------------------------------------------------
            // DISPLAY EACH SCENE
            // ----------------------------------------------------

            scenes.forEach(function (scene, index) {

                console.log(
                    "------------------------------------------------"
                );


                console.log(
                    "[Performer Custom Field Counter] SCENE #" +
                    (index + 1)
                );


                console.log(
                    "ID:",
                    scene.id
                );


                console.log(
                    "Title:",
                    scene.title
                );


                console.log(
                    "custom_fields:",
                    scene.custom_fields
                );


                console.log(
                    "custom_fields typeof:",
                    typeof scene.custom_fields
                );


                let rawValue;


                if (
                    scene.custom_fields &&
                    typeof scene.custom_fields === "object"
                ) {

                    rawValue =
                        scene.custom_fields[
                            CONFIG.fieldName
                        ];
                }


                console.log(
                    "custom_field [" +
                    CONFIG.fieldName +
                    "]:",
                    rawValue
                );


                console.log(
                    "custom_field typeof:",
                    typeof rawValue
                );


                console.log(
                    "performers:",
                    scene.performers
                );


                console.log(
                    "performers typeof:",
                    typeof scene.performers
                );


                if (Array.isArray(scene.performers)) {

                    console.log(
                        "performer count:",
                        scene.performers.length
                    );


                    scene.performers.forEach(
                        function (performer, performerIndex) {

                            console.log(
                                "performer #" +
                                (performerIndex + 1) +
                                ":",
                                performer
                            );

                        }
                    );

                } else {

                    console.warn(
                        "[Performer Custom Field Counter] " +
                        "performers is not an array:",
                        scene.performers
                    );
                }

            });


            // ----------------------------------------------------
            // NO AGGREGATION YET
            // ----------------------------------------------------

            totalsByPerformer = new Map();

            loadedAt = Date.now();


            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] END"
            );

            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // OVERLAY
    //
    // IMPORTANT:
    // Do NOT use React directly here.
    //
    // We use the same mechanism that was already confirmed
    // working in Stash v0.31.1.
    // ============================================================

    function createCounterOverlay(performerId) {

        const element =
            document.createElement("div");


        element.className =
            "performer-custom-field-counter";


        element.style.position =
            "absolute";


        element.style.top =
            "5px";


        element.style.right =
            "5px";


        element.style.zIndex =
            "100";


        element.style.backgroundColor =
            "rgba(0, 0, 0, 0.85)";


        element.style.color =
            "white";


        element.style.padding =
            "3px 7px";


        element.style.borderRadius =
            "4px";


        element.style.fontSize =
            "12px";


        element.style.fontWeight =
            "bold";


        element.style.lineHeight =
            "16px";


        element.style.pointerEvents =
            "none";


        element.textContent =
            "...";


        loadTotals()
            .then(function (totals) {

                const total =
                    totals.get(
                        String(performerId)
                    ) || 0;


                element.textContent =
                    String(total);

            })
            .catch(function (error) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "Unable to load counter:",
                    error
                );


                element.textContent =
                    "0";
            });


        return element;
    }


    // ============================================================
    // PERFORMER CARD PATCH
    // ============================================================

    window.PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            const performer =
                props &&
                props.performer;


            if (!performer || !performer.id) {
                return null;
            }


            // ----------------------------------------------------
            // IMPORTANT
            //
            // This is only a diagnostic overlay.
            // We deliberately do NOT return "original"
            // because that caused the React child error.
            // ----------------------------------------------------

            if (!CONFIG.showCounter) {
                return null;
            }


            return createCounterOverlay(
                String(performer.id)
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            totalsByPerformer =
                new Map();

            loadedAt = 0;

            return await loadTotals(true);
        },


        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        clearCache() {

            totalsByPerformer =
                new Map();

            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] Cache cleared."
            );
        },


        async diagnostic() {

            console.log(
                "[Performer Custom Field Counter] " +
                "Running diagnostic..."
            );


            totalsByPerformer =
                new Map();

            loadedAt = 0;


            return await loadTotals(true);
        },


        status() {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                loadedAt:
                    loadedAt,

                cacheEntries:
                    totalsByPerformer.size,

                diagnosticMode:
                    CONFIG.diagnosticMode,
            };
        },
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target Stash version: 0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Custom field:",
        CONFIG.fieldName
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Diagnostic mode:",
        CONFIG.diagnosticMode
    );

})();