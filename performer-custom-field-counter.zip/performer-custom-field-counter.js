(function () {
    "use strict";

    const React = window.PluginApi.React;

    // ============================================================
    // Configuration
    // ============================================================

    const CONFIG = {
        fieldName: "custom_field",

        pageSize: 500,

        cacheDuration: 5 * 60 * 1000,

        hideZero: false,

        /*
         * Diagnostic mode.
         *
         * IMPORTANT:
         * We deliberately do NOT render the original
         * PerformerCard.Overlays result while testing.
         */
        diagnosticMode: true,
    };


    // ============================================================
    // Cache
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GraphQL
    // ============================================================

    async function graphql(query, variables = {}) {

        const response = await fetch("/graphql", {
            method: "POST",

            credentials: "same-origin",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });


        if (!response.ok) {
            throw new Error(
                `GraphQL request failed: ${response.status} ${response.statusText}`
            );
        }


        const result = await response.json();


        if (result.errors) {

            console.error(
                "[Performer Custom Field Counter] GraphQL errors:",
                result.errors
            );

            throw new Error(
                result.errors[0]?.message ||
                "Unknown GraphQL error"
            );
        }


        return result.data;
    }


    // ============================================================
    // Load scene totals
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        /*
         * Return cached values if they are still valid.
         */
        if (
            !forceRefresh &&
            loadedAt > 0 &&
            Date.now() - loadedAt < CONFIG.cacheDuration
        ) {
            return totalsByPerformer;
        }


        /*
         * Prevent multiple simultaneous full-library loads.
         */
        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async () => {

            console.log(
                "[Performer Custom Field Counter] " +
                "Starting scene aggregation..."
            );


            const totals = new Map();

            let page = 1;

            let totalPages = 1;


            do {

                console.log(
                    "[Performer Custom Field Counter] " +
                    `Loading page ${page}/${totalPages}`
                );


                const query = `
                    query PerformerCustomFieldCounter(
                        $filter: FindFilterType
                    ) {
                        findScenes(
                            filter: $filter
                        ) {
                            count
                            pages

                            scenes {
                                id

                                custom_fields

                                performers {
                                    performer {
                                        id
                                    }
                                }
                            }
                        }
                    }
                `;


                const data = await graphql(query, {
                    filter: {
                        page: page,
                        per_page: CONFIG.pageSize,
                    },
                });


                const result = data?.findScenes;


                if (!result) {
                    console.warn(
                        "[Performer Custom Field Counter] " +
                        "findScenes returned no result."
                    );

                    break;
                }


                totalPages = result.pages || 1;


                for (const scene of result.scenes || []) {

                    const rawValue =
                        scene.custom_fields?.[CONFIG.fieldName];


                    /*
                     * Ignore scenes without the custom field.
                     */
                    if (
                        rawValue === null ||
                        rawValue === undefined ||
                        rawValue === ""
                    ) {
                        continue;
                    }


                    /*
                     * custom_field is expected to be an integer.
                     */
                    const value = Number(rawValue);


                    if (!Number.isInteger(value)) {

                        console.warn(
                            "[Performer Custom Field Counter] " +
                            `Invalid value for scene ${scene.id}:`,
                            rawValue
                        );

                        continue;
                    }


                    /*
                     * Add the scene value to every performer
                     * associated with the scene.
                     */
                    for (const performerEntry of scene.performers || []) {

                        const performer =
                            performerEntry?.performer;


                        if (!performer?.id) {
                            continue;
                        }


                        const performerId =
                            String(performer.id);


                        const current =
                            totals.get(performerId) || 0;


                        totals.set(
                            performerId,
                            current + value
                        );
                    }
                }


                page++;

            } while (page <= totalPages);


            /*
             * Replace the cache only after the complete
             * aggregation has finished.
             */
            totalsByPerformer = totals;

            loadedAt = Date.now();


            console.log(
                "[Performer Custom Field Counter] " +
                `Aggregation complete: ${totals.size} performers`
            );


            return totals;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // Counter overlay
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] = React.useState(null);


        React.useEffect(() => {

            let cancelled = false;


            loadTotals()
                .then((totals) => {

                    if (cancelled) {
                        return;
                    }


                    const total =
                        totals.get(String(performerId)) || 0;


                    setValue(total);
                })
                .catch((error) => {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "Unable to calculate counter:",
                        error
                    );


                    if (!cancelled) {
                        setValue(0);
                    }
                });


            return () => {
                cancelled = true;
            };

        }, [performerId]);


        /*
         * Loading state.
         */
        if (value === null) {

            return React.createElement(
                "div",
                {
                    className:
                        "performer-custom-field-counter",

                    style: {
                        position: "absolute",
                        top: "5px",
                        right: "5px",

                        background: "red",
                        color: "white",

                        padding: "4px 8px",

                        borderRadius: "4px",

                        zIndex: 9999,

                        pointerEvents: "none",
                    },
                },
                "..."
            );
        }


        /*
         * Hide zero if configured.
         */
        if (
            CONFIG.hideZero &&
            value === 0
        ) {
            return null;
        }


        /*
         * IMPORTANT:
         *
         * We explicitly convert the value to a string.
         *
         * This guarantees that React receives a primitive
         * value and never an object.
         */
        const displayValue = String(value);


        return React.createElement(
            "div",
            {
                className:
                    "performer-custom-field-counter",

                title:
                    `${CONFIG.fieldName}: ${displayValue}`,

                style: {
                    position: "absolute",

                    top: "5px",
                    right: "5px",

                    minWidth: "2rem",
                    height: "2rem",

                    padding: "0 8px",

                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",

                    background: "rgba(0, 0, 0, 0.85)",

                    color: "white",

                    borderRadius: "5px",

                    fontSize: "14px",
                    fontWeight: "bold",

                    zIndex: 9999,

                    pointerEvents: "none",
                },
            },

            displayValue
        );
    }


    // ============================================================
    // PerformerCard.Overlays patch
    // ============================================================

    window.PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            console.log(
                "[Performer Custom Field Counter] " +
                "PerformerCard.Overlays called",
                {
                    performer: props?.performer,

                    originalType:
                        typeof original,

                    originalConstructor:
                        original?.constructor?.name,

                    originalIsArray:
                        Array.isArray(original),
                }
            );


            const performer =
                props?.performer;


            if (!performer?.id) {

                console.warn(
                    "[Performer Custom Field Counter] " +
                    "No performer found in patch arguments."
                );


                /*
                 * Diagnostic mode:
                 * return null rather than potentially returning
                 * an invalid object.
                 */
                if (CONFIG.diagnosticMode) {
                    return null;
                }


                return original;
            }


            /*
             * Create our overlay.
             */
            const counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            String(performer.id),
                    }
                );


            /*
             * ====================================================
             * DIAGNOSTIC MODE
             * ====================================================
             *
             * We intentionally DO NOT include "original".
             *
             * This is the important test.
             *
             * If this works, the problem is definitely caused by
             * trying to render/reinsert "original".
             */
            if (CONFIG.diagnosticMode) {

                return React.createElement(
                    React.Fragment,
                    null,

                    counter
                );
            }


            /*
             * ====================================================
             * NORMAL MODE
             * ====================================================
             *
             * Once we confirm that the diagnostic version works,
             * this section can be enabled.
             */
            return React.createElement(
                React.Fragment,
                null,

                original,

                counter
            );
        }
    );


    // ============================================================
    // Debug API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            console.log(
                "[Performer Custom Field Counter] " +
                "Refreshing cache..."
            );


            totalsByPerformer = new Map();

            loadedAt = 0;


            return await loadTotals(true);
        },


        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        clearCache() {

            totalsByPerformer = new Map();

            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        status() {

            return {
                fieldName: CONFIG.fieldName,

                cachedPerformers:
                    totalsByPerformer.size,

                loadedAt:
                    loadedAt
                        ? new Date(loadedAt).toISOString()
                        : null,

                cacheAge:
                    loadedAt
                        ? Date.now() - loadedAt
                        : null,

                diagnosticMode:
                    CONFIG.diagnosticMode,
            };
        },
    };


    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded successfully."
    );

})();