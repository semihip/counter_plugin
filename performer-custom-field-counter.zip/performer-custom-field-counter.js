(function () {
    "use strict";

    // ============================================================
    // STASH VERSION
    // ============================================================

    // This plugin is specifically developed for:
    // Stash v0.31.1


    // ============================================================
    // PLUGIN API
    // ============================================================

    const PluginApi = window.PluginApi;


    if (!PluginApi) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi is not available."
        );

        return;
    }


    // IMPORTANT:
    // React is exposed by Stash through PluginApi.React.
    //
    // Do NOT use window.React.
    // Do NOT assume React is a global variable.

    const React = PluginApi.React;


    if (!React) {

        console.error(
            "[Performer Custom Field Counter] " +
            "PluginApi.React is not available."
        );

        console.error(
            "[Performer Custom Field Counter] " +
            "Available PluginApi properties:",
            Object.keys(PluginApi)
        );

        return;
    }


    console.log(
        "[Performer Custom Field Counter] " +
        "PluginApi.React is available."
    );


    // ============================================================
    // CONFIGURATION
    // ============================================================

    const CONFIG = {

        // Name of the Stash scene custom field
        fieldName: "custom_field",

        // Number of scenes retrieved during diagnostic
        pageSize: 10,

        // Cache duration
        cacheDuration: 5 * 60 * 1000,

        // Diagnostic mode
        diagnosticMode: true,

        // Always show zero
        hideZero: false,
    };


    // ============================================================
    // STATE
    // ============================================================

    let totalsByPerformer = new Map();

    let loadedAt = 0;

    let loadingPromise = null;


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables = {}) {

        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL query:",
            query
        );


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL variables:",
            variables
        );


        const response = await fetch(
            "/graphql",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                },

                body: JSON.stringify({
                    query: query,
                    variables: variables,
                }),
            }
        );


        let json;


        try {

            json = await response.json();

        } catch (error) {

            throw new Error(
                "Unable to parse GraphQL response. " +
                "HTTP " +
                response.status +
                " " +
                response.statusText
            );
        }


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL HTTP:",
            response.status,
            response.statusText
        );


        console.log(
            "[Performer Custom Field Counter] " +
            "GraphQL raw response:",
            json
        );


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText +
                " | " +
                JSON.stringify(json)
            );
        }


        if (json.errors) {

            throw new Error(
                "GraphQL errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD DATA
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        if (
            !forceRefresh &&
            loadedAt > 0 &&
            Date.now() - loadedAt <
                CONFIG.cacheDuration
        ) {

            return totalsByPerformer;
        }


        if (loadingPromise) {

            return loadingPromise;
        }


        loadingPromise = (async function () {

            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "START DIAGNOSTIC"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Target Stash version: 0.31.1"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Custom field:",
                CONFIG.fieldName
            );


            // ----------------------------------------------------
            // IMPORTANT:
            //
            // For this diagnostic test we deliberately DO NOT
            // request custom_fields.
            //
            // First we verify that the basic Scene query works.
            // ----------------------------------------------------

            const query = `
                query PerformerCustomFieldCounter(
                    $filter: FindFilterType
                ) {
                    findScenes(
                        filter: $filter
                    ) {
                        count

                        scenes {
                            id
                            title

                            performers {
                                id
                                name
                            }
                        }
                    }
                }
            `;


            let data;


            try {

                data = await graphql(
                    query,
                    {
                        filter: {
                            page: 1,
                            per_page: CONFIG.pageSize,
                        },
                    }
                );

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "ERROR:",
                    error
                );


                totalsByPerformer =
                    new Map();


                return totalsByPerformer;
            }


            // ----------------------------------------------------
            // GRAPHQL DATA
            // ----------------------------------------------------

            console.log(
                "[Performer Custom Field Counter] " +
                "GRAPHQL DATA:",
                data
            );


            const findScenes =
                data?.findScenes;


            if (!findScenes) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "findScenes is missing."
                );


                totalsByPerformer =
                    new Map();


                return totalsByPerformer;
            }


            const scenes =
                findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] " +
                "Total scenes:",
                findScenes.count
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Scenes returned:",
                scenes.length
            );


            // ----------------------------------------------------
            // DISPLAY EACH SCENE
            // ----------------------------------------------------

            scenes.forEach(function (scene, index) {

                console.log(
                    "------------------------------------------------"
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "SCENE #" +
                    (index + 1)
                );


                console.log(
                    "ID:",
                    scene.id
                );


                console.log(
                    "TITLE:",
                    scene.title
                );


                console.log(
                    "PERFORMERS:",
                    scene.performers
                );


                if (Array.isArray(scene.performers)) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Performer count:",
                        scene.performers.length
                    );


                    scene.performers.forEach(
                        function (performer, performerIndex) {

                            console.log(
                                "  Performer #" +
                                (performerIndex + 1) +
                                ":",
                                {
                                    id: performer?.id,
                                    name: performer?.name,
                                }
                            );
                        }
                    );

                } else {

                    console.warn(
                        "[Performer Custom Field Counter] " +
                        "performers is not an array:",
                        scene.performers
                    );
                }

            });


            // ----------------------------------------------------
            // NO AGGREGATION YET
            // ----------------------------------------------------

            totalsByPerformer =
                new Map();


            loadedAt =
                Date.now();


            console.log(
                "================================================"
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "END DIAGNOSTIC"
            );


            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // COUNTER OVERLAY
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] =
            React.useState(null);


        React.useEffect(
            function () {

                let cancelled = false;


                async function load() {

                    try {

                        const totals =
                            await loadTotals();


                        if (cancelled) {
                            return;
                        }


                        const total =
                            totals.get(
                                String(performerId)
                            ) || 0;


                        setValue(total);

                    } catch (error) {

                        console.error(
                            "[Performer Custom Field Counter] " +
                            "Counter error:",
                            error
                        );


                        if (!cancelled) {

                            setValue(0);
                        }
                    }
                }


                load();


                return function () {

                    cancelled = true;
                };

            },
            [performerId]
        );


        if (
            CONFIG.hideZero &&
            value === 0
        ) {

            return null;
        }


        const displayValue =
            value === null
                ? "..."
                : String(value);


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",

                    top: "5px",

                    right: "5px",

                    zIndex: 100,

                    backgroundColor:
                        "rgba(0, 0, 0, 0.85)",

                    color: "white",

                    padding: "3px 7px",

                    borderRadius: "4px",

                    fontSize: "12px",

                    fontWeight: "bold",

                    lineHeight: "16px",

                    pointerEvents: "none",
                },
            },
            displayValue
        );
    }


    // ============================================================
    // PATCH PERFORMER CARD
    // ============================================================

    PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            const performer =
                props?.performer;


            if (!performer?.id) {

                return null;
            }


            const counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            String(performer.id),
                    }
                );


            // ----------------------------------------------------
            // Diagnostic mode:
            //
            // Do not return "original".
            // This was the version that successfully displayed 0.
            // ----------------------------------------------------

            if (CONFIG.diagnosticMode) {

                return React.createElement(
                    React.Fragment,
                    null,
                    counter
                );
            }


            return React.createElement(
                React.Fragment,
                null,
                original,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        async refresh() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            return await loadTotals(true);
        },


        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        clearCache() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        async diagnostic() {

            totalsByPerformer =
                new Map();


            loadedAt = 0;


            return await loadTotals(true);
        },


        status() {

            return {
                stashVersion: "0.31.1",

                fieldName:
                    CONFIG.fieldName,

                loadedAt:
                    loadedAt,

                cacheEntries:
                    totalsByPerformer.size,

                diagnosticMode:
                    CONFIG.diagnosticMode,

                reactAvailable:
                    !!PluginApi.React,
            };
        },
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "Target: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "PluginApi.React:",
        PluginApi.React
    );


    console.log(
        "[Performer Custom Field Counter] " +
        "React available:",
        !!PluginApi.React
    );


})();