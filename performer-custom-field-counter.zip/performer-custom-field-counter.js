```javascript
(function () {
    "use strict";

    // ============================================================
    // STASH VERSION
    // ============================================================

    // Target:
    // Stash v0.31.1


    // ============================================================
    // PLUGIN API
    // ============================================================

    var PluginApi = window.PluginApi;

    if (!PluginApi) {
        console.error(
            "[Performer Custom Field Counter] PluginApi is not available."
        );
        return;
    }


    // React is obtained explicitly from PluginApi.
    var React = PluginApi.React;

    if (!React) {
        console.error(
            "[Performer Custom Field Counter] PluginApi.React is not available."
        );

        console.error(
            "[Performer Custom Field Counter] Available PluginApi properties:",
            Object.keys(PluginApi)
        );

        return;
    }


    console.log(
        "[Performer Custom Field Counter] PluginApi.React is available."
    );


    // ============================================================
    // CONFIGURATION
    // ============================================================

    var CONFIG = {

        fieldName: "custom_field",

        // Only retrieve a few scenes for this diagnostic.
        pageSize: 5,

        // Only individually inspect this many scenes.
        diagnosticSceneLimit: 5,

        diagnosticMode: true,

        hideZero: false
    };


    // ============================================================
    // STATE
    // ============================================================

    var totalsByPerformer = new Map();

    var loadingPromise = null;


    // ============================================================
    // GRAPHQL HELPER
    // ============================================================

    async function graphql(query, variables) {

        if (!variables) {
            variables = {};
        }

        console.log(
            "[Performer Custom Field Counter] GraphQL query:",
            query
        );

        console.log(
            "[Performer Custom Field Counter] GraphQL variables:",
            variables
        );


        var response = await fetch(
            "/graphql",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json"
                },

                body: JSON.stringify({
                    query: query,
                    variables: variables
                })
            }
        );


        var json;

        try {

            json = await response.json();

        } catch (error) {

            throw new Error(
                "Unable to parse GraphQL response. HTTP " +
                response.status +
                " " +
                response.statusText
            );
        }


        console.log(
            "[Performer Custom Field Counter] GraphQL HTTP:",
            response.status,
            response.statusText
        );


        console.log(
            "[Performer Custom Field Counter] GraphQL response:",
            json
        );


        if (!response.ok) {

            throw new Error(
                "GraphQL HTTP error: " +
                response.status +
                " " +
                response.statusText
            );
        }


        if (json.errors) {

            throw new Error(
                "GraphQL errors: " +
                JSON.stringify(json.errors)
            );
        }


        return json.data;
    }


    // ============================================================
    // LOAD / DIAGNOSTIC
    // ============================================================

    async function loadTotals(forceRefresh) {

        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async function () {

            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] START DIAGNOSTIC"
            );

            console.log(
                "[Performer Custom Field Counter] Target: Stash v0.31.1"
            );


            // ====================================================
            // STEP 1
            // Get scenes.
            //
            // IMPORTANT:
            // Do not request performers here.
            // ====================================================

            var scenesQuery =
                "query PerformerCustomFieldCounter($filter: FindFilterType) {" +
                " findScenes(filter: $filter) {" +
                "   count" +
                "   scenes {" +
                "     id" +
                "     title" +
                "   }" +
                " }" +
                "}";


            var scenesData;


            try {

                scenesData = await graphql(
                    scenesQuery,
                    {
                        filter: {
                            page: 1,
                            per_page: CONFIG.pageSize
                        }
                    }
                );

            } catch (error) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "ERROR retrieving scenes:",
                    error
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            console.log(
                "[Performer Custom Field Counter] " +
                "Scenes query result:",
                scenesData
            );


            // ====================================================
            // STEP 2
            // Validate result.
            // ====================================================

            if (
                !scenesData ||
                !scenesData.findScenes
            ) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "findScenes is missing."
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            var findScenes =
                scenesData.findScenes;


            var scenes =
                findScenes.scenes || [];


            console.log(
                "[Performer Custom Field Counter] " +
                "Total scenes in database:",
                findScenes.count
            );


            console.log(
                "[Performer Custom Field Counter] " +
                "Scenes returned:",
                scenes.length
            );


            if (scenes.length === 0) {

                console.error(
                    "[Performer Custom Field Counter] " +
                    "No scenes returned."
                );

                totalsByPerformer = new Map();

                return totalsByPerformer;
            }


            // ====================================================
            // STEP 3
            // Individually query each scene.
            // ====================================================

            var limit =
                Math.min(
                    CONFIG.diagnosticSceneLimit,
                    scenes.length
                );


            console.log(
                "[Performer Custom Field Counter] " +
                "Individual scene tests:",
                limit
            );


            var singleSceneQuery =
                "query PerformerCustomFieldCounterSingleScene($id: ID) {" +
                " findScene(id: $id) {" +
                "   id" +
                "   title" +
                "   performers {" +
                "     id" +
                "     name" +
                "   }" +
                " }" +
                "}";


            var index;


            for (
                index = 0;
                index < limit;
                index++
            ) {

                var scene =
                    scenes[index];


                console.log(
                    "------------------------------------------------"
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "TEST SCENE #" +
                    (index + 1)
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scene ID:",
                    scene.id
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "Scene title:",
                    scene.title
                );


                var singleSceneData;


                try {

                    singleSceneData =
                        await graphql(
                            singleSceneQuery,
                            {
                                id: String(scene.id)
                            }
                        );

                } catch (error) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "ERROR retrieving scene:",
                        scene.id,
                        error
                    );

                    continue;
                }


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene result:",
                    singleSceneData
                );


                if (
                    !singleSceneData ||
                    !singleSceneData.findScene
                ) {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "findScene returned no scene for ID:",
                        scene.id
                    );

                    continue;
                }


                var singleScene =
                    singleSceneData.findScene;


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene ID:",
                    singleScene.id
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene TITLE:",
                    singleScene.title
                );


                console.log(
                    "[Performer Custom Field Counter] " +
                    "findScene PERFORMERS:",
                    singleScene.performers
                );


                if (
                    Array.isArray(singleScene.performers)
                ) {

                    console.log(
                        "[Performer Custom Field Counter] " +
                        "Performer count:",
                        singleScene.performers.length
                    );


                    if (
                        singleScene.performers.length === 0
                    ) {

                        console.warn(
                            "[Performer Custom Field Counter] " +
                            "WARNING: zero performers returned."
                        );

                    } else {

                        var performerIndex;


                        for (
                            performerIndex = 0;
                            performerIndex <
                            singleScene.performers.length;
                            performerIndex++
                        ) {

                            var performer =
                                singleScene.performers[
                                    performerIndex
                                ];


                            console.log(
                                "[Performer Custom Field Counter] " +
                                "Performer #" +
                                (performerIndex + 1) +
                                ":",
                                performer
                            );


                            console.log(
                                "    ID:",
                                performer.id
                            );


                            console.log(
                                "    NAME:",
                                performer.name
                            );
                        }
                    }

                } else {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "performers is not an array:",
                        singleScene.performers
                    );
                }
            }


            // ====================================================
            // STEP 4
            // No aggregation yet.
            // ====================================================

            totalsByPerformer = new Map();


            console.log(
                "================================================"
            );

            console.log(
                "[Performer Custom Field Counter] END DIAGNOSTIC"
            );

            console.log(
                "================================================"
            );


            return totalsByPerformer;

        })();


        try {

            return await loadingPromise;

        } finally {

            loadingPromise = null;
        }
    }


    // ============================================================
    // COUNTER OVERLAY
    // ============================================================

    function CounterOverlay(props) {

        var performerId =
            props.performerId;


        var state =
            React.useState(null);


        var value =
            state[0];


        var setValue =
            state[1];


        React.useEffect(
            function () {

                var cancelled = false;


                async function load() {

                    try {

                        var totals =
                            await loadTotals(false);


                        if (cancelled) {
                            return;
                        }


                        var total =
                            totals.get(
                                String(performerId)
                            );


                        if (typeof total !== "number") {
                            total = 0;
                        }


                        setValue(total);

                    } catch (error) {

                        console.error(
                            "[Performer Custom Field Counter] " +
                            "Counter error:",
                            error
                        );


                        if (!cancelled) {
                            setValue(0);
                        }
                    }
                }


                load();


                return function () {
                    cancelled = true;
                };

            },
            [performerId]
        );


        if (
            CONFIG.hideZero &&
            value === 0
        ) {
            return null;
        }


        var displayValue;


        if (value === null) {
            displayValue = "...";
        } else {
            displayValue = String(value);
        }


        return React.createElement(
            "div",
            {
                style: {
                    position: "absolute",
                    top: "5px",
                    right: "5px",
                    zIndex: 100,
                    backgroundColor: "rgba(0, 0, 0, 0.85)",
                    color: "white",
                    padding: "3px 7px",
                    borderRadius: "4px",
                    fontSize: "12px",
                    fontWeight: "bold",
                    lineHeight: "16px",
                    pointerEvents: "none"
                }
            },
            displayValue
        );
    }


    // ============================================================
    // PATCH PERFORMER CARD
    // ============================================================

    PluginApi.patch.after(
        "PerformerCard.Overlays",
        function (props, original) {

            if (
                !props ||
                !props.performer ||
                !props.performer.id
            ) {
                return null;
            }


            var counter =
                React.createElement(
                    CounterOverlay,
                    {
                        performerId:
                            String(props.performer.id)
                    }
                );


            if (CONFIG.diagnosticMode) {

                return React.createElement(
                    React.Fragment,
                    null,
                    counter
                );
            }


            return React.createElement(
                React.Fragment,
                null,
                original,
                counter
            );
        }
    );


    // ============================================================
    // DEBUG API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        diagnostic: function () {

            totalsByPerformer =
                new Map();

            return loadTotals(true);
        },


        refresh: function () {

            totalsByPerformer =
                new Map();

            return loadTotals(true);
        },


        getTotal: function (performerId) {

            var value =
                totalsByPerformer.get(
                    String(performerId)
                );


            if (typeof value !== "number") {
                return 0;
            }


            return value;
        },


        clearCache: function () {

            totalsByPerformer =
                new Map();


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        status: function () {

            return {
                stashVersion: "0.31.1",
                fieldName: CONFIG.fieldName,
                cacheEntries: totalsByPerformer.size,
                diagnosticMode: CONFIG.diagnosticMode,
                reactAvailable: !!PluginApi.React
            };
        }
    };


    // ============================================================
    // INITIALIZATION
    // ============================================================

    console.log(
        "[Performer Custom Field Counter] Plugin loaded."
    );


    console.log(
        "[Performer Custom Field Counter] Target: Stash v0.31.1"
    );


    console.log(
        "[Performer Custom Field Counter] PluginApi.React:",
        PluginApi.React
    );


    console.log(
        "[Performer Custom Field Counter] React available:",
        !!PluginApi.React
    );

})();
```
