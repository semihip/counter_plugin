(function () {
    "use strict";

    const React = window.PluginApi.React;

    // ============================================================
    // Configuration
    // ============================================================

    const CONFIG = {
        // Name of the Stash scene custom field
        fieldName: "custom_field",

        // Number of scenes retrieved per GraphQL request
        pageSize: 500,

        // Cache duration in milliseconds
        // 5 minutes
        cacheDuration: 5 * 60 * 1000,

        // Hide the badge when the calculated value is zero
        hideZero: true,
    };


    // ============================================================
    // Global cache
    // ============================================================

    /*
     * Map:
     *
     * performer ID -> sum of custom_field
     *
     * Example:
     *
     * "123" -> 42
     * "456" -> 17
     */
    let totalsByPerformer = new Map();

    let loadedAt = 0;

    /*
     * Shared promise.
     *
     * If several performer cards are rendered at the same time,
     * they all wait for the same loading operation instead of
     * starting multiple GraphQL queries.
     */
    let loadingPromise = null;


    // ============================================================
    // GraphQL helper
    // ============================================================

    async function graphql(query, variables = {}) {
        const response = await fetch("/graphql", {
            method: "POST",
            credentials: "same-origin",

            headers: {
                "Content-Type": "application/json",
            },

            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });


        if (!response.ok) {
            throw new Error(
                `GraphQL request failed: ${response.status} ${response.statusText}`
            );
        }


        const result = await response.json();


        if (result.errors) {
            console.error(
                "[Performer Custom Field Counter] GraphQL errors:",
                result.errors
            );

            throw new Error(
                result.errors[0]?.message ||
                "Unknown GraphQL error"
            );
        }


        return result.data;
    }


    // ============================================================
    // Load all scenes and calculate performer totals
    // ============================================================

    async function loadTotals(forceRefresh = false) {

        /*
         * Return the existing cache if it is still valid.
         */
        if (
            !forceRefresh &&
            loadedAt > 0 &&
            Date.now() - loadedAt < CONFIG.cacheDuration
        ) {
            return totalsByPerformer;
        }


        /*
         * If another card is already loading the data,
         * reuse that request.
         */
        if (loadingPromise) {
            return loadingPromise;
        }


        loadingPromise = (async () => {

            const newTotals = new Map();

            let page = 1;
            let totalPages = 1;


            do {

                console.log(
                    `[Performer Custom Field Counter] ` +
                    `Loading scene page ${page}/${totalPages}`
                );


                const query = `
                    query PerformerCustomFieldCounter(
                        $filter: FindFilterType
                    ) {
                        findScenes(
                            filter: $filter
                        ) {
                            count
                            pages

                            scenes {
                                id

                                custom_fields

                                performers {
                                    performer {
                                        id
                                    }
                                }
                            }
                        }
                    }
                `;


                const data = await graphql(query, {
                    filter: {
                        page: page,
                        per_page: CONFIG.pageSize,
                    },
                });


                const result = data?.findScenes;


                if (!result) {
                    break;
                }


                totalPages = result.pages || 1;


                const scenes = result.scenes || [];


                for (const scene of scenes) {

                    /*
                     * Get the custom field value.
                     */
                    const rawValue =
                        scene.custom_fields?.[CONFIG.fieldName];


                    /*
                     * Ignore missing values.
                     */
                    if (
                        rawValue === null ||
                        rawValue === undefined ||
                        rawValue === ""
                    ) {
                        continue;
                    }


                    /*
                     * The field is expected to contain an integer.
                     */
                    const value = Number(rawValue);


                    /*
                     * Ignore invalid values.
                     */
                    if (!Number.isInteger(value)) {
                        console.warn(
                            "[Performer Custom Field Counter] " +
                            `Ignoring invalid ${CONFIG.fieldName} value ` +
                            `for scene ${scene.id}:`,
                            rawValue
                        );

                        continue;
                    }


                    /*
                     * Add the value to every performer associated
                     * with the scene.
                     *
                     * Example:
                     *
                     * Scene:
                     *     custom_field = 10
                     *     performers = Alice, Bob
                     *
                     * Result:
                     *     Alice += 10
                     *     Bob   += 10
                     */
                    for (const performerEntry of scene.performers || []) {

                        const performer =
                            performerEntry?.performer;


                        if (!performer?.id) {
                            continue;
                        }


                        const performerId =
                            String(performer.id);


                        const currentTotal =
                            newTotals.get(performerId) || 0;


                        newTotals.set(
                            performerId,
                            currentTotal + value
                        );
                    }
                }


                page++;

            } while (page <= totalPages);


            /*
             * Replace the cache only after the complete operation
             * has succeeded.
             */
            totalsByPerformer = newTotals;

            loadedAt = Date.now();


            console.log(
                "[Performer Custom Field Counter] " +
                `Loaded ${newTotals.size} performer totals`
            );


            return totalsByPerformer;

        })();


        try {
            return await loadingPromise;

        } finally {
            loadingPromise = null;
        }
    }


    // ============================================================
    // React counter component
    // ============================================================

    function CounterOverlay({ performerId }) {

        const [value, setValue] = React.useState(null);


        React.useEffect(() => {

            let cancelled = false;


            loadTotals()
                .then((totals) => {

                    if (cancelled) {
                        return;
                    }


                    const total =
                        totals.get(String(performerId)) || 0;


                    setValue(total);
                })

                .catch((error) => {

                    console.error(
                        "[Performer Custom Field Counter] " +
                        "Failed to load totals:",
                        error
                    );


                    if (!cancelled) {
                        setValue(0);
                    }
                });


            return () => {
                cancelled = true;
            };

        }, [performerId]);


        /*
         * Do not render anything while the data is loading.
         */
        if (value === null) {
            return null;
        }


        /*
         * Optionally hide zero values.
         */
        if (CONFIG.hideZero && value === 0) {
            return null;
        }


        return React.createElement(
            "div",
            {
                className:
                    "performer-custom-field-counter",

                title:
                    `${CONFIG.fieldName}: ${value}`,
            },

            value
        );
    }


    // ============================================================
    // Patch PerformerCard.Overlays
    // ============================================================

    window.PluginApi.patch.after(
        "PerformerCard.Overlays",

        function (props, original) {

            /*
             * PerformerCard.Overlays receives the PerformerCard props
             * directly.
             */
            const performer = props?.performer;


            if (!performer?.id) {
                return original;
            }


            /*
             * IMPORTANT:
             *
             * Do not render "original" as a child if it is an object
             * that React cannot interpret.
             *
             * In Stash 0.31.1, the original patched component result
             * is expected to be a React element.
             */
            return React.createElement(
                React.Fragment,
                null,

                original,

                React.createElement(
                    CounterOverlay,
                    {
                        performerId: performer.id,
                    }
                )
            );
        }
    );


    // ============================================================
    // Developer / debugging API
    // ============================================================

    window.PerformerCustomFieldCounter = {

        /*
         * Force a complete refresh of the cache.
         *
         * Browser console:
         *
         * PerformerCustomFieldCounter.refresh()
         */
        async refresh() {

            console.log(
                "[Performer Custom Field Counter] " +
                "Forcing cache refresh..."
            );


            totalsByPerformer = new Map();

            loadedAt = 0;


            const totals =
                await loadTotals(true);


            console.log(
                "[Performer Custom Field Counter] " +
                `Refresh complete. ${totals.size} performers.`
            );


            return totals;
        },


        /*
         * Get the currently cached value for a performer.
         *
         * Browser console:
         *
         * PerformerCustomFieldCounter.getTotal("123")
         */
        getTotal(performerId) {

            return (
                totalsByPerformer.get(
                    String(performerId)
                ) || 0
            );
        },


        /*
         * Clear the cache without immediately reloading it.
         */
        clearCache() {

            totalsByPerformer = new Map();

            loadedAt = 0;


            console.log(
                "[Performer Custom Field Counter] " +
                "Cache cleared."
            );
        },


        /*
         * Show basic plugin status.
         */
        status() {

            return {
                fieldName: CONFIG.fieldName,

                cachedPerformers:
                    totalsByPerformer.size,

                loadedAt:
                    loadedAt
                        ? new Date(loadedAt).toISOString()
                        : null,

                cacheAge:
                    loadedAt
                        ? Date.now() - loadedAt
                        : null,
            };
        },
    };


    console.log(
        "[Performer Custom Field Counter] " +
        "Plugin loaded."
    );

})();